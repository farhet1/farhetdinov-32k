import React from 'react';
import './ProfilePage.module.css';

export const ProfilePage = () => {
  return (
    <div>
      <h1>Profile Page</h1>
      <p>Welcome to the Profile Page!</p>
    </div>
  );
};
