import React from 'react';
import './ActionPage.module.css';

export const ActionPage = () => {
  return (
    <div>
      <h1>Action Page</h1>
      <p>Welcome to the Action Page!</p>
    </div>
  );
};
